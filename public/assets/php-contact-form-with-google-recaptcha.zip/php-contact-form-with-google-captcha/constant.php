<?php
//reCAPTCHA Configuration - go to Google and get the below keys http://www.google.com/recaptcha/admin
define('SITE_KEY',"SITE_KEY"); 
define('SECRET_KEY',"SECRET_KEY)
?>